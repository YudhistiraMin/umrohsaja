			$(document).ready(function(){
					$('#btn-up').click(function(){
						$(window).scrollTop(0);
					});
					$(window).scrollTop(0);

					var menu = 0;
					var width = document.body.clientWidth;
					var height = document.body.clientHeight;

					$(".nav-link").removeClass("active");
					$('.navbar-toggler').click(function(){
						width = document.body.clientWidth;
						height = $(window).scrollTop();
						if($(this).attr('data-status-active')==0){
							$(this).attr('data-status-active','1');
						}else{
							$(this).attr('data-status-active','0');
						}
						if(menu == 0){

							$(".fixed-top").addClass("top-nav-collapse");
							$(".nav-link").css("color" , "#fff");
							$(".nav-link.active").css("color" , "#fff");
							menu = 1;

						} else {
							if(width >= 320){
								if(height <= 30){
									$(".fixed-top").removeClass("top-nav-collapse");
									$(".nav-link").css("color" , "white");
									$(".nav-link.active").css("color" , "white");
								} else {
									$(".fixed-top").addClass("top-nav-collapse");
									$(".nav-link").css("color" , "#fff");
									$(".nav-link.active").css("color" , "#fff");

								}
							} else {
								$(".fixed-top").addClass("top-nav-collapse");
								$(".nav-link").css("color" , "black");
								$(".nav-link.active").css("color" , "black");
							}

							menu = 0;
						}
					});

					$(window).scroll(function(){
						var width = document.body.clientWidth;

						if(width >= 320){
							if($(window).scrollTop() <= 30) {
					// alert("mbu");
					$("#navbar-menu-bars").css("color","white");
					if($('.navbar-toggler').attr('data-status-active')==0){
						$(".fixed-top").removeClass("top-nav-collapse");
					}
					$(".nav-link").css("color" , "white");
				} else {
					$("#navbar-menu-bars").css("color","black");
					$(".fixed-top").addClass("top-nav-collapse");								
				}
			} else {
				$(".fixed-top").addClass("top-nav-collapse");
				$(".nav-link").css("color" , "white");
				$(".nav-link.active").css("color" , "white");
			}

		});
				});
